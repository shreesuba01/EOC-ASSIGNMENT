def int2bit16(v):
    v=int(v)
    return "{:016b}".format(v)[1:16]

F = open(r"C:\Users\sshre\Downloads\nand2tetris\nand2tetris\projects\06\max\MaxL.asm",'r')
H=F.readlines()
List=[]

#   For Memory register
a1 = {
    'M':'110000', 'D-M':'010011', 
     }

#   For Address register
a0={
    '0':'101010', 'D':'001100', 
   }
# To replace comments with white space in each line and then remove the white space

for i in H:
    a=i.find("//")
    if(a==-1):
        c=i.strip()
        List.append(c)
        
    else:
        b=i.replace(i[a:],'')
        B=b.strip()
        List.append(B)
        

# To remove white spaces caused by comments

while ('' in List):
    List.remove("")

    
#   Destination values
dest={
        'M': '001', 'D': '010'
     }

#   Jump values
jump={
        'JGT':'001', 'JMP':'111'
    }

for V in List:
#To convert A instruction to its binary form
    n=V.find('@')
    if(n!=-1):
        b=int2bit16(V[n+1:])
        c='0'+str(b)
        List[List.index(V)]=c

#C instruction to its binary from
    else:
        p=V.find('=')
        k=V.find(';')
        if(p!=-1):
            if(k!=-1):
                d=V.split('=')
                d1=d[1].split(';')
                d=d.remove(d[1])
                d.extend(d1[0],d1[1])
            
                for D1 in dest:
                    if(D1==d[0]):
                        D.append(dest[D1])

                if(d[1].find('M')!=-1):
                    for C1 in a1:
                        if(C1==d[1]):
                            C=a1[C1]
                            A='1'
                else:
                    for C1 in a0:
                        if(C1==d[1]):
                            C=a0[C1]
                            A='0'
                            
                for J1 in jump:
                    if(J1==d[2]):
                        J.append(jump[J1])
                V1='111'+A+C+D+J
                List[List.index(V)]=V1
            else:
                d=V.split('=')
                for D2 in dest:
                    if(D2==d[0]):
                        D=dest[D2]
                if(d[1].find('M')!=-1):
                    for C2 in a1:
                        if(C2==d[1]):
                            C=a1[C2]
                            A='1'
                else:
                    for C2 in a0:
                        if(C2==d[1]):
                            C=a0[C2]
                            A='0'

            
                V2='111'+A+C+D+'000'

                List[List.index(V)]=V2
                
        else:
            d=V.split(';')
        
            for J2 in jump:
                if(J2==d[1]):
                    J=jump[J2]
    
            if(d[0].find('M')!=-1):
                for C2 in a1:
                    if(C2==d[0]):
                        C=a1[C2]
                        A='1'
            else:
                for C2 in a0:
                    if(C2==d[0]):
                        C=a0[C2]
                        A='0'
 
            V3='111'+A+C+'000'+J
            List[List.index(V)]=V3
      
G=open('MaxL.hack','w')
for s in List:
    G.write(s)
    G.write('\n')
G.close()
    
